﻿#include "Commands.h"

int main()
{	
	Commands cmd;
	cmd.run();
}