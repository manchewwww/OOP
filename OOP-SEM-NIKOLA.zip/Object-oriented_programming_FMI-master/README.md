## Материали от лекции, семинари и практикуми по "Обектно-ориентирано програмиране"
#### летен семестър 2022/2023, спец. Софтуерно инженерство & Информационни системи
- [Материали от упражнения](https://github.com/Justsvetoslavov/Object-oriented_programming_FMI/tree/master/Seminars)
- [Инструкции за работа с Github](https://github.com/Justsvetoslavov/Object-oriented_programming_FMI/tree/master/Github-Workflow)
