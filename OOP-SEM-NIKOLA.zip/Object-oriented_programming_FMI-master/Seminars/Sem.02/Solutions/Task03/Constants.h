#pragma once

const int FIELD_MAX_SIZE = 50;
const int BUFFER_LINE_SIZE = 1024;
