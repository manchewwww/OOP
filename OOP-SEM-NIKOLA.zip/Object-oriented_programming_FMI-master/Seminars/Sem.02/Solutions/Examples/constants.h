#pragma once

const short BUFFER_SIZE = 1024;
const char FILE_NAME[] = "test.txt";
const char INVALID_FILE_ERR_MSG[] = "Error opening the file";
