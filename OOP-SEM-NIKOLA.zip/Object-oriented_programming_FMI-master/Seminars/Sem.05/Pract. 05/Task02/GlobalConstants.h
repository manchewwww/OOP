#pragma once

namespace GlobalConstants {
	const double EPSILON = 0.000001;
}