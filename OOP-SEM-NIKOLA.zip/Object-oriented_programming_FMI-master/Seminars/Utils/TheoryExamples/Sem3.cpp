// https://github.com/GeorgiTerziev02/Object-oriented_programming_FMI/tree/main/Sem.%2003
// Check carefully reading and writing from/to binary file
// in all scenarios