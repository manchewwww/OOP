#pragma once

bool isLower(char ch);
bool isSymbol(char ch);
void toUpper(char* str);
unsigned charToDigit(char ch);
unsigned convertToNumber(const char* str);