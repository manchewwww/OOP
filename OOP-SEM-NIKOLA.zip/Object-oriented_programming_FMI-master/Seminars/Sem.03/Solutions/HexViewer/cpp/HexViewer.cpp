#include "../startUp.h"

int main()
{
	run();
	return 0;
}