#pragma once

#include "file.h"

void startMenu(File& file);

void run();
