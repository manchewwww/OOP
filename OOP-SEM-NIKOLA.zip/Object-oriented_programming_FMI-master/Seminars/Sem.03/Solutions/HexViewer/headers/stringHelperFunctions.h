#pragma once

int strLength(const char* str);

char* subStr(const char* str, const int& startIndex, const int& endIndex);

bool strCmp(const char* str1, const char* str2);