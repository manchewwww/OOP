#include "CollectionOperation.h"

CollectionOperation::CollectionOperation(Collection& l, Collection& r) :
	left(l), right(r) {}
